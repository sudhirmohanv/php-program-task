<?php
$str_data = file_get_contents("emp-records.json");
$data = json_decode($str_data, true);
$temp = "<table border=2>";
 
$temp .= "<tr><th>Menu Header</th><th>Id</th><th>Label</th>";
$temp .= "</tr>";
 
 
 //array of label and id
 $id=array();
 $label=array();
 
$j=0;
for($i = 0; $i < sizeof($data["menu"]["items"]); $i++)
{
	if($data["menu"]["items"]!=null)
	{
$temp .= "<tr>";
$temp .= "<td>" . $data["menu"]["header"]. "</td>";
$temp .= "<td>" . $data["menu"]["items"][$i]["id"] . "</td>";
$temp .= "<td>" . @$data["menu"]["items"][$i]["label"] . "</td>";
$temp .= "</tr>";

array_push($id, $data["menu"]["items"][$i]["id"]);
array_push($label,@$data["menu"]["items"][$i]["label"]);
}
}

$temp .= "</table>";

echo $temp;
?>

<h3>Array of Id is :</h3>
<?php
foreach($id as $i)
{
	echo $i."<br/>";
}
?>

<h3>Array of label is :</h3>
<?php
foreach($label as $l)
{
	echo $l."<br/>";
}
?>